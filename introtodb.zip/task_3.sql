USE alx_book_store;
SHOW TABLES;